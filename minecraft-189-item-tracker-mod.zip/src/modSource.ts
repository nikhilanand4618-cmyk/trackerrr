export interface SourceFile {
  path: string;
  lang: string;
  content: string;
}

export const files: SourceFile[] = [
  {
    path: "build.gradle",
    lang: "groovy",
    content: `buildscript {
    repositories {
        mavenCentral()
        maven { url = "https://maven.minecraftforge.net" }
        maven { url = "https://repo.spongepowered.org/maven" }
    }
    dependencies {
        classpath 'net.minecraftforge.gradle:ForgeGradle:1.2-SNAPSHOT'
    }
}

apply plugin: 'forge'

version = "1.0.0"
group = "com.droptracker"
archivesBaseName = "DropTracker"

sourceCompatibility = 1.8
targetCompatibility = 1.8

minecraft {
    version = "1.8.9-11.15.1.2318-1.8.9"
    runDir = "run"
    mappings = "stable_22"
}

processResources {
    inputs.property "version", project.version
    inputs.property "mcversion", project.minecraft.version
    from(sourceSets.main.resources.srcDirs) {
        include 'mcmod.info'
        expand 'version': project.version, 'mcversion': project.minecraft.version
    }
    from(sourceSets.main.resources.srcDirs) {
        exclude 'mcmod.info'
    }
}`,
  },
  {
    path: "src/main/resources/mcmod.info",
    lang: "json",
    content: `[
{
  "modid": "droptracker",
  "name": "Drop Tracker",
  "description": "Tracks dropped items from Hypixel Skyblock slayer chat, with prices and a draggable HUD.",
  "version": "\${version}",
  "mcversion": "\${mcversion}",
  "authorList": ["you"],
  "credits": "",
  "logoFile": "",
  "screenshots": [],
  "dependencies": []
}
]`,
  },
  {
    path: "src/main/java/com/droptracker/DropTracker.java",
    lang: "java",
    content: `package com.droptracker;

import com.droptracker.command.SetPriceCommand;
import com.droptracker.command.TrackerGuiCommand;
import com.droptracker.config.TrackerConfig;
import com.droptracker.gui.GuiHandler;
import com.droptracker.hud.HudRenderer;
import com.droptracker.listener.ChatListener;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

import java.io.File;

@Mod(modid = DropTracker.MODID, name = DropTracker.NAME, version = DropTracker.VERSION, clientSideOnly = true)
public class DropTracker {
    public static final String MODID = "droptracker";
    public static final String NAME = "Drop Tracker";
    public static final String VERSION = "1.0.0";

    public static TrackerConfig config;
    public static GuiHandler guiHandler;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        File dir = new File(Minecraft.getMinecraft().mcDataDir, "config/droptracker");
        if (!dir.exists()) dir.mkdirs();
        config = new TrackerConfig(new File(dir, "data.json"));
        config.load();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        guiHandler = new GuiHandler();
        MinecraftForge.EVENT_BUS.register(new ChatListener());
        MinecraftForge.EVENT_BUS.register(new HudRenderer());
        MinecraftForge.EVENT_BUS.register(guiHandler);
        ClientCommandHandler.instance.registerCommand(new SetPriceCommand());
        ClientCommandHandler.instance.registerCommand(new TrackerGuiCommand());
    }
}`,
  },
  {
    path: "src/main/java/com/droptracker/config/TrackerConfig.java",
    lang: "java",
    content: `package com.droptracker.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/** Persists prices, drop counts, HUD position and toggles to config/droptracker/data.json */
public class TrackerConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final File file;

    public static class Data {
        public boolean hudEnabled = true;
        public boolean trackingEnabled = true;
        public int hudX = 5;
        public int hudY = 5;
        public float hudScale = 1.0f;
        /** display name -> price per item (coins) */
        public Map<String, Long> prices = new LinkedHashMap<String, Long>();
        /** display name -> total amount dropped */
        public Map<String, Integer> drops = new LinkedHashMap<String, Integer>();
    }

    public Data data = new Data();

    public TrackerConfig(File file) {
        this.file = file;
    }

    public void load() {
        if (!file.exists()) { save(); return; }
        try {
            Reader r = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8);
            Type t = new TypeToken<Data>() {}.getType();
            Data loaded = GSON.fromJson(r, t);
            r.close();
            if (loaded != null) data = loaded;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void save() {
        try {
            Writer w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8);
            GSON.toJson(data, w);
            w.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addDrop(String name, int amount) {
        Integer cur = data.drops.get(name);
        data.drops.put(name, (cur == null ? 0 : cur) + amount);
        save();
    }

    public long getPrice(String name) {
        Long p = data.prices.get(name);
        return p == null ? 0L : p;
    }

    public long totalValue() {
        long total = 0;
        for (Map.Entry<String, Integer> e : data.drops.entrySet()) {
            total += getPrice(e.getKey()) * e.getValue();
        }
        return total;
    }
}`,
  },
  {
    path: "src/main/java/com/droptracker/listener/ChatListener.java",
    lang: "java",
    content: `package com.droptracker.listener;

import com.droptracker.DropTracker;
import net.minecraft.util.EnumChatFormatting;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Listens to incoming chat and records drops.
 * IMPORTANT: we never cancel the event, so vanilla chat is NEVER blocked.
 *
 * Hypixel Skyblock slayer drop messages look like:
 *   RARE DROP! (Tarantula Web)
 *   RARE DROP! Toxic Arrow Poison (+150% ✯ Magic Find)
 *   VERY RARE DROP!  (Fly Swatter)
 *   CRAZY RARE DROP!  (Digested Mosquito)
 *   RARE DROP! 2x Spider Catalyst
 * Plus generic auto-pickup messages (e.g. from mods / sacks):
 *   [Sacks] +32 String
 */
public class ChatListener {

    private static final Pattern RARE_DROP = Pattern.compile(
        "^(?:PET DROP|CRAZY RARE DROP|VERY RARE DROP|RARE DROP)!\\\\s*\\\\(?(?:(\\\\d+)x )?([^()]+?)\\\\)?\\\\s*(?:\\\\(\\\\+\\\\d+% .*Magic Find\\\\))?$"
    );
    private static final Pattern SACK_PICKUP = Pattern.compile("^\\\\[Sacks\\\\] \\\\+(\\\\d[\\\\d,]*) (.+?)(?: \\\\(.*\\\\))?$");
    private static final Pattern PICKUP = Pattern.compile("^\\\\+(\\\\d+)x? (.+)$");

    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = false)
    public void onChat(ClientChatReceivedEvent event) {
        if (event.type == 2) return; // action bar
        if (!DropTracker.config.data.trackingEnabled) return;

        String raw = EnumChatFormatting.getTextWithoutFormattingCodes(event.message.getUnformattedText()).trim();
        if (raw.isEmpty()) return;

        Matcher m = RARE_DROP.matcher(raw);
        if (m.find()) {
            int amount = m.group(1) == null ? 1 : Integer.parseInt(m.group(1));
            record(m.group(2).trim(), amount);
            return;
        }
        m = SACK_PICKUP.matcher(raw);
        if (m.find()) {
            record(m.group(2).trim(), Integer.parseInt(m.group(1).replace(",", "")));
            return;
        }
        m = PICKUP.matcher(raw);
        if (m.find()) {
            record(m.group(2).trim(), Integer.parseInt(m.group(1)));
        }
        // event is intentionally NOT cancelled -> chat displays normally
    }

    private void record(String item, int amount) {
        DropTracker.config.addDrop(item, amount);
    }
}`,
  },
  {
    path: "src/main/java/com/droptracker/command/SetPriceCommand.java",
    lang: "java",
    content: `package com.droptracker.command;

import com.droptracker.DropTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

import java.util.Arrays;
import java.util.List;

/**
 * /setprice <price>          -> sets price of the item currently held
 * /setprice <price> <name..> -> sets price for a named item
 * Price accepts k / m suffixes, e.g. 110k, 1.5m
 */
public class SetPriceCommand extends CommandBase {

    @Override public String getCommandName() { return "setprice"; }
    @Override public List<String> getCommandAliases() { return Arrays.asList("sp"); }
    @Override public String getCommandUsage(ICommandSender sender) { return "/setprice <price> [item name]"; }
    @Override public int getRequiredPermissionLevel() { return 0; }
    @Override public boolean canCommandSenderUseCommand(ICommandSender sender) { return true; }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length < 1) { msg(EnumChatFormatting.RED + "Usage: " + getCommandUsage(sender)); return; }

        long price;
        try { price = parsePrice(args[0]); }
        catch (NumberFormatException e) { msg(EnumChatFormatting.RED + "Invalid price: " + args[0]); return; }

        String name;
        if (args.length >= 2) {
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i < args.length; i++) { if (i > 1) sb.append(' '); sb.append(args[i]); }
            name = sb.toString();
        } else {
            ItemStack held = Minecraft.getMinecraft().thePlayer.getHeldItem();
            if (held == null) { msg(EnumChatFormatting.RED + "Hold an item or specify a name."); return; }
            name = EnumChatFormatting.getTextWithoutFormattingCodes(held.getDisplayName()).trim();
        }

        DropTracker.config.data.prices.put(name, price);
        DropTracker.config.save();
        msg(EnumChatFormatting.GREEN + "Set price of " + EnumChatFormatting.YELLOW + name
            + EnumChatFormatting.GREEN + " to " + EnumChatFormatting.GOLD + format(price) + " coins");
    }

    public static long parsePrice(String s) {
        s = s.toLowerCase().replace(",", "").trim();
        double mult = 1;
        if (s.endsWith("k")) { mult = 1_000; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("m")) { mult = 1_000_000; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("b")) { mult = 1_000_000_000; s = s.substring(0, s.length() - 1); }
        return Math.round(Double.parseDouble(s) * mult);
    }

    public static String format(long n) {
        if (n >= 1_000_000_000L) return String.format("%.2fb", n / 1e9);
        if (n >= 1_000_000L) return String.format("%.2fm", n / 1e6);
        if (n >= 1_000L) return String.format("%.1fk", n / 1e3);
        return String.valueOf(n);
    }

    private void msg(String s) {
        Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(
            EnumChatFormatting.DARK_GRAY + "[" + EnumChatFormatting.AQUA + "Tracker" + EnumChatFormatting.DARK_GRAY + "] " + s));
    }
}`,
  },
  {
    path: "src/main/java/com/droptracker/command/TrackerGuiCommand.java",
    lang: "java",
    content: `package com.droptracker.command;

import com.droptracker.DropTracker;
import com.droptracker.gui.GuiTracker;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;

import java.util.Arrays;
import java.util.List;

/** /trackergui -> opens the tracker GUI on the next client tick (can't open a GUI from inside a command directly). */
public class TrackerGuiCommand extends CommandBase {
    @Override public String getCommandName() { return "trackergui"; }
    @Override public List<String> getCommandAliases() { return Arrays.asList("tracker", "tg"); }
    @Override public String getCommandUsage(ICommandSender sender) { return "/trackergui"; }
    @Override public int getRequiredPermissionLevel() { return 0; }
    @Override public boolean canCommandSenderUseCommand(ICommandSender sender) { return true; }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        DropTracker.guiHandler.openNextTick(new GuiTracker());
    }
}`,
  },
  {
    path: "src/main/java/com/droptracker/gui/GuiHandler.java",
    lang: "java",
    content: `package com.droptracker.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameplay.TickEvent;

/** Defers GUI opening to the next tick so the chat GUI closing doesn't immediately close ours. */
public class GuiHandler {
    private GuiScreen pending;

    public void openNextTick(GuiScreen screen) { pending = screen; }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || pending == null) return;
        Minecraft.getMinecraft().displayGuiScreen(pending);
        pending = null;
    }
}`,
  },
  {
    path: "src/main/java/com/droptracker/gui/GuiTracker.java",
    lang: "java",
    content: `package com.droptracker.gui;

import com.droptracker.DropTracker;
import com.droptracker.command.SetPriceCommand;
import com.droptracker.config.TrackerConfig;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.EnumChatFormatting;

import java.io.IOException;
import java.util.Map;

/** Main tracker GUI: toggles + drop list + buttons for dragging the HUD and resetting. */
public class GuiTracker extends GuiScreen {
    private static final int BTN_HUD = 0, BTN_TRACK = 1, BTN_DRAG = 2, BTN_RESET = 3, BTN_CLOSE = 4;
    private int scroll = 0;

    @Override
    public void initGui() {
        buttonList.clear();
        int cx = width / 2;
        int y = 30;
        buttonList.add(new GuiButton(BTN_HUD, cx - 155, y, 150, 20, hudText()));
        buttonList.add(new GuiButton(BTN_TRACK, cx + 5, y, 150, 20, trackText()));
        buttonList.add(new GuiButton(BTN_DRAG, cx - 155, y + 24, 150, 20, "Move HUD (drag)"));
        buttonList.add(new GuiButton(BTN_RESET, cx + 5, y + 24, 150, 20, EnumChatFormatting.RED + "Reset drops"));
        buttonList.add(new GuiButton(BTN_CLOSE, cx - 50, height - 28, 100, 20, "Close"));
    }

    private String hudText() { return "HUD: " + onOff(DropTracker.config.data.hudEnabled); }
    private String trackText() { return "Tracking: " + onOff(DropTracker.config.data.trackingEnabled); }
    private String onOff(boolean b) { return b ? EnumChatFormatting.GREEN + "ON" : EnumChatFormatting.RED + "OFF"; }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        TrackerConfig.Data d = DropTracker.config.data;
        switch (button.id) {
            case BTN_HUD: d.hudEnabled = !d.hudEnabled; button.displayString = hudText(); break;
            case BTN_TRACK: d.trackingEnabled = !d.trackingEnabled; button.displayString = trackText(); break;
            case BTN_DRAG: mc.displayGuiScreen(new GuiHudEditor()); return;
            case BTN_RESET: d.drops.clear(); break;
            case BTN_CLOSE: mc.displayGuiScreen(null); return;
        }
        DropTracker.config.save();
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int wheel = org.lwjgl.input.Mouse.getEventDWheel();
        if (wheel > 0 && scroll > 0) scroll--;
        if (wheel < 0 && scroll < Math.max(0, DropTracker.config.data.drops.size() - 10)) scroll++;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        int cx = width / 2;
        drawCenteredString(fontRendererObj, EnumChatFormatting.AQUA + "" + EnumChatFormatting.BOLD + "Drop Tracker", cx, 10, 0xFFFFFF);

        TrackerConfig cfg = DropTracker.config;
        int top = 82;
        int boxH = Math.min(height - top - 40, 12 * 11 + 8);
        drawRect(cx - 160, top, cx + 160, top + boxH, 0x90000000);

        int y = top + 4;
        drawString(fontRendererObj, EnumChatFormatting.GRAY + "Item", cx - 155, y, 0xFFFFFF);
        drawString(fontRendererObj, EnumChatFormatting.GRAY + "Amount", cx + 20, y, 0xFFFFFF);
        drawString(fontRendererObj, EnumChatFormatting.GRAY + "Value", cx + 85, y, 0xFFFFFF);
        y += 12;

        int i = 0;
        for (Map.Entry<String, Integer> e : cfg.data.drops.entrySet()) {
            if (i++ < scroll) continue;
            if (y + 10 > top + boxH) break;
            long value = cfg.getPrice(e.getKey()) * e.getValue();
            String name = fontRendererObj.trimStringToWidth(e.getKey(), 170);
            drawString(fontRendererObj, EnumChatFormatting.YELLOW + name, cx - 155, y, 0xFFFFFF);
            drawString(fontRendererObj, EnumChatFormatting.WHITE + "x" + e.getValue(), cx + 20, y, 0xFFFFFF);
            String priceStr = cfg.getPrice(e.getKey()) == 0 ? EnumChatFormatting.DARK_GRAY + "no price" : EnumChatFormatting.GOLD + SetPriceCommand.format(value);
            drawString(fontRendererObj, priceStr, cx + 85, y, 0xFFFFFF);
            y += 11;
        }
        if (cfg.data.drops.isEmpty()) {
            drawCenteredString(fontRendererObj, EnumChatFormatting.DARK_GRAY + "No drops tracked yet", cx, y + 20, 0xFFFFFF);
        }

        drawCenteredString(fontRendererObj, EnumChatFormatting.GRAY + "Total: " + EnumChatFormatting.GOLD + SetPriceCommand.format(cfg.totalValue()) + " coins"
            + EnumChatFormatting.DARK_GRAY + "  |  set prices with /setprice <price> while holding an item", cx, top + boxH + 6, 0xFFFFFF);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override public boolean doesGuiPauseGame() { return false; }
}`,
  },
  {
    path: "src/main/java/com/droptracker/gui/GuiHudEditor.java",
    lang: "java",
    content: `package com.droptracker.gui;

import com.droptracker.DropTracker;
import com.droptracker.config.TrackerConfig;
import com.droptracker.hud.HudRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.EnumChatFormatting;

import java.io.IOException;

/** Drag-and-drop HUD position editor. Left-drag moves, scroll wheel resizes, ESC saves & returns. */
public class GuiHudEditor extends GuiScreen {
    private boolean dragging = false;
    private int dragOffX, dragOffY;

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawCenteredString(fontRendererObj, EnumChatFormatting.GRAY + "Drag the HUD to move it. Scroll to resize. Press ESC to save.", width / 2, 10, 0xFFFFFF);

        TrackerConfig.Data d = DropTracker.config.data;
        int w = HudRenderer.getWidth(fontRendererObj), h = HudRenderer.getHeight();
        int sw = (int) (w * d.hudScale), sh = (int) (h * d.hudScale);
        boolean hover = isOver(mouseX, mouseY);
        drawRect(d.hudX - 2, d.hudY - 2, d.hudX + sw + 2, d.hudY + sh + 2, hover || dragging ? 0x6000FFFF : 0x40FFFFFF);
        HudRenderer.render(fontRendererObj, true);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private boolean isOver(int mx, int my) {
        TrackerConfig.Data d = DropTracker.config.data;
        int sw = (int) (HudRenderer.getWidth(fontRendererObj) * d.hudScale), sh = (int) (HudRenderer.getHeight() * d.hudScale);
        return mx >= d.hudX - 2 && mx <= d.hudX + sw + 2 && my >= d.hudY - 2 && my <= d.hudY + sh + 2;
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (mouseButton == 0 && isOver(mouseX, mouseY)) {
            dragging = true;
            dragOffX = mouseX - DropTracker.config.data.hudX;
            dragOffY = mouseY - DropTracker.config.data.hudY;
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int button, long timeSinceLastClick) {
        if (!dragging) return;
        TrackerConfig.Data d = DropTracker.config.data;
        ScaledResolution sr = new ScaledResolution(mc);
        int sw = (int) (HudRenderer.getWidth(fontRendererObj) * d.hudScale), sh = (int) (HudRenderer.getHeight() * d.hudScale);
        d.hudX = Math.max(0, Math.min(sr.getScaledWidth() - sw, mouseX - dragOffX));
        d.hudY = Math.max(0, Math.min(sr.getScaledHeight() - sh, mouseY - dragOffY));
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        dragging = false;
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int wheel = org.lwjgl.input.Mouse.getEventDWheel();
        if (wheel != 0) {
            TrackerConfig.Data d = DropTracker.config.data;
            d.hudScale = Math.max(0.5f, Math.min(3f, d.hudScale + (wheel > 0 ? 0.1f : -0.1f)));
        }
    }

    @Override
    public void onGuiClosed() {
        DropTracker.config.save();
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1) { // ESC -> back to tracker gui
            DropTracker.config.save();
            mc.displayGuiScreen(new GuiTracker());
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override public boolean doesGuiPauseGame() { return false; }
}`,
  },
  {
    path: "src/main/java/com/droptracker/hud/HudRenderer.java",
    lang: "java",
    content: `package com.droptracker.hud;

import com.droptracker.DropTracker;
import com.droptracker.command.SetPriceCommand;
import com.droptracker.config.TrackerConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.EnumChatFormatting;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Draws the drop list overlay in-game. */
public class HudRenderer {
    private static final int MAX_LINES = 8;

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.TEXT) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.gameSettings.showDebugInfo) return;
        if (!DropTracker.config.data.hudEnabled) return;
        if (mc.currentScreen instanceof com.droptracker.gui.GuiHudEditor) return; // editor draws it itself
        render(mc.fontRendererObj, false);
    }

    public static List<String> buildLines() {
        TrackerConfig cfg = DropTracker.config;
        List<String> lines = new ArrayList<String>();
        lines.add(EnumChatFormatting.AQUA + "" + EnumChatFormatting.BOLD + "Drop Tracker");
        int shown = 0;
        for (Map.Entry<String, Integer> e : cfg.data.drops.entrySet()) {
            if (shown++ >= MAX_LINES) { lines.add(EnumChatFormatting.DARK_GRAY + "..."); break; }
            long price = cfg.getPrice(e.getKey());
            String val = price == 0 ? "" : EnumChatFormatting.DARK_GRAY + " (" + EnumChatFormatting.GOLD + SetPriceCommand.format(price * e.getValue()) + EnumChatFormatting.DARK_GRAY + ")";
            lines.add(EnumChatFormatting.YELLOW + e.getKey() + EnumChatFormatting.GRAY + ": " + EnumChatFormatting.WHITE + e.getValue() + val);
        }
        if (cfg.data.drops.isEmpty()) lines.add(EnumChatFormatting.DARK_GRAY + "No drops yet");
        lines.add(EnumChatFormatting.GRAY + "Total: " + EnumChatFormatting.GOLD + SetPriceCommand.format(cfg.totalValue()));
        return lines;
    }

    public static int getWidth(FontRenderer fr) {
        int w = 0;
        for (String s : buildLines()) w = Math.max(w, fr.getStringWidth(s));
        return w + 6;
    }

    public static int getHeight() {
        return buildLines().size() * 10 + 4;
    }

    public static void render(FontRenderer fr, boolean editor) {
        TrackerConfig.Data d = DropTracker.config.data;
        List<String> lines = buildLines();
        GlStateManager.pushMatrix();
        GlStateManager.translate(d.hudX, d.hudY, 0);
        GlStateManager.scale(d.hudScale, d.hudScale, 1);
        Gui.drawRect(0, 0, getWidth(fr), getHeight(), 0x70000000);
        int y = 2;
        for (String s : lines) {
            fr.drawStringWithShadow(s, 3, y, 0xFFFFFF);
            y += 10;
        }
        GlStateManager.popMatrix();
    }
}`,
  },
];
