import { useState } from "react";
import Simulator from "./Simulator";
import { files } from "./modSource";

export default function App() {
  const [active, setActive] = useState(2);
  const [copied, setCopied] = useState<string | null>(null);
  const file = files[active];

  const copy = async (text: string, key: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 1500);
  };

  const copyAll = () =>
    copy(files.map((f) => `// ===== ${f.path} =====\n${f.content}`).join("\n\n"), "all");

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-200">
      <header className="border-b border-neutral-800">
        <div className="mx-auto max-w-6xl px-4 py-10">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-cyan-800 bg-cyan-950/50 px-3 py-1 text-xs text-cyan-300">
            Forge 1.8.9 · Client-side · Hypixel SkyBlock
          </div>
          <h1 className="text-4xl font-bold text-white">Drop Tracker Mod</h1>
          <p className="mt-3 max-w-2xl text-neutral-400">
            Tracks slayer drops from chat (never blocks chat), a draggable on/off HUD, item prices via{" "}
            <code className="text-cyan-300">/setprice 110k</code> for the item you're holding, and a dedicated GUI opened with{" "}
            <code className="text-cyan-300">/trackergui</code>.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href="#source" className="rounded-md bg-cyan-600 px-4 py-2 font-medium text-white hover:bg-cyan-500">View source</a>
            <a href="#install" className="rounded-md border border-neutral-700 px-4 py-2 font-medium hover:bg-neutral-900">Build instructions</a>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-14 px-4 py-10">
        <section>
          <h2 className="mb-1 text-2xl font-semibold text-white">Live simulator</h2>
          <p className="mb-4 text-sm text-neutral-400">Interactive preview of exactly what the mod does in-game. Same regexes and command logic as the Java code.</p>
          <Simulator />
        </section>

        <section>
          <h2 className="mb-4 text-2xl font-semibold text-white">Features</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["Chat drop tracking", "Parses RARE / VERY RARE / CRAZY RARE / PET DROP and sack pickups. Event is never cancelled, so your chat is untouched."],
              ["/setprice", "Detects the item in your hand (e.g. Water Bucket) and sets its price. Accepts 110k, 1.5m, 2b. Or pass a name: /setprice 50k Tarantula Web."],
              ["/trackergui", "Own GUI with HUD on/off, tracking on/off, full drop list with amounts & values, reset button, and a HUD position editor."],
              ["Draggable HUD", "Drag to move, scroll to scale. Position, prices and counts are saved to config/droptracker/data.json."],
            ].map(([t, d]) => (
              <div key={t} className="rounded-lg border border-neutral-800 bg-neutral-900 p-4">
                <div className="font-semibold text-white">{t}</div>
                <p className="mt-1 text-sm text-neutral-400">{d}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="source">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-2xl font-semibold text-white">Mod source code</h2>
            <button onClick={copyAll} className="rounded-md border border-neutral-700 px-3 py-1.5 text-sm hover:bg-neutral-900">
              {copied === "all" ? "Copied!" : "Copy all files"}
            </button>
          </div>
          <div className="grid overflow-hidden rounded-lg border border-neutral-800 lg:grid-cols-[280px_1fr]">
            <aside className="border-b border-neutral-800 bg-neutral-900 lg:border-b-0 lg:border-r">
              {files.map((f, i) => (
                <button key={f.path} onClick={() => setActive(i)}
                  className={`block w-full truncate px-3 py-2 text-left font-mono text-xs hover:bg-neutral-800 ${i === active ? "bg-neutral-800 text-cyan-300" : "text-neutral-400"}`}
                  title={f.path}>
                  {f.path.replace("src/main/java/com/droptracker/", "…/").replace("src/main/resources/", "res/")}
                </button>
              ))}
            </aside>
            <div className="min-w-0 bg-[#0d0d0f]">
              <div className="flex items-center justify-between border-b border-neutral-800 px-3 py-2">
                <span className="truncate font-mono text-xs text-neutral-400">{file.path}</span>
                <button onClick={() => copy(file.content, file.path)} className="rounded bg-neutral-800 px-2 py-1 text-xs hover:bg-neutral-700">
                  {copied === file.path ? "Copied!" : "Copy"}
                </button>
              </div>
              <pre className="max-h-[600px] overflow-auto p-4 font-mono text-[12px] leading-5 text-neutral-200">
                <code>{file.content}</code>
              </pre>
            </div>
          </div>
        </section>

        <section id="install">
          <h2 className="mb-4 text-2xl font-semibold text-white">Build & install</h2>
          <ol className="list-decimal space-y-3 pl-5 text-sm text-neutral-300">
            <li>Download the <b>Forge 1.8.9 MDK</b> (11.15.1.2318) and extract it. Make sure you have <b>JDK 8</b> installed.</li>
            <li>Replace <code className="text-cyan-300">build.gradle</code> with the one above and create the files under <code className="text-cyan-300">src/main/java/com/droptracker/…</code> and <code className="text-cyan-300">src/main/resources/mcmod.info</code>.</li>
            <li>Run <code className="rounded bg-neutral-900 px-1.5 py-0.5 text-cyan-300">./gradlew setupDecompWorkspace build</code> (use <code className="text-cyan-300">gradlew.bat</code> on Windows).</li>
            <li>Copy <code className="text-cyan-300">build/libs/DropTracker-1.0.0.jar</code> to your <code className="text-cyan-300">.minecraft/mods</code> folder and launch Forge 1.8.9.</li>
            <li>In game: hold an item → <code className="text-cyan-300">/setprice 110k</code>. Open the GUI with <code className="text-cyan-300">/trackergui</code> (aliases <code className="text-cyan-300">/tracker</code>, <code className="text-cyan-300">/tg</code>). Use "Move HUD" to drag it anywhere.</li>
          </ol>
          <div className="mt-4 rounded-lg border border-amber-900/60 bg-amber-950/30 p-3 text-xs text-amber-200">
            Tip: if Hypixel changes a drop message format, only <code>ChatListener.java</code> needs editing — add another regex to <code>onChat</code>.
          </div>
        </section>
      </main>

      <footer className="border-t border-neutral-800 py-6 text-center text-xs text-neutral-500">Drop Tracker · Forge 1.8.9 · client-side only</footer>
    </div>
  );
}
