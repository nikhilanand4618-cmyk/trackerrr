import { useEffect, useRef, useState } from "react";

const RARE_DROP =
  /^(?:PET DROP|CRAZY RARE DROP|VERY RARE DROP|RARE DROP)!\s*\(?(?:(\d+)x )?([^()]+?)\)?\s*(?:\(\+\d+% .*Magic Find\))?$/;
const SACK_PICKUP = /^\[Sacks\] \+(\d[\d,]*) (.+?)(?: \(.*\))?$/;
const PICKUP = /^\+(\d+)x? (.+)$/;

function parsePrice(s: string): number | null {
  s = s.toLowerCase().replace(/,/g, "").trim();
  let mult = 1;
  if (s.endsWith("k")) { mult = 1e3; s = s.slice(0, -1); }
  else if (s.endsWith("m")) { mult = 1e6; s = s.slice(0, -1); }
  else if (s.endsWith("b")) { mult = 1e9; s = s.slice(0, -1); }
  const n = parseFloat(s);
  return isNaN(n) ? null : Math.round(n * mult);
}
export function fmt(n: number) {
  if (n >= 1e9) return (n / 1e9).toFixed(2) + "b";
  if (n >= 1e6) return (n / 1e6).toFixed(2) + "m";
  if (n >= 1e3) return (n / 1e3).toFixed(1) + "k";
  return String(n);
}

const HELD_ITEMS = ["Water Bucket", "Tarantula Web", "Toxic Arrow Poison", "Fly Swatter", "Spider Catalyst", "Digested Mosquito"];

const SLAYER_MESSAGES = [
  "RARE DROP! (Tarantula Web)",
  "RARE DROP! Toxic Arrow Poison (+150% ✯ Magic Find)",
  "VERY RARE DROP!  (Fly Swatter)",
  "CRAZY RARE DROP!  (Digested Mosquito)",
  "RARE DROP! 2x Spider Catalyst",
  "[Sacks] +32 String",
  "  SLAYER QUEST COMPLETE!",
  "   Tarantula Broodfather Tier IV LVL 7 ➜ LVL 8",
  "[MVP+] Someone: lol nice drop",
  "RARE DROP! (Tarantula Web)",
];

interface Line { text: string; color: string; }

export default function Simulator() {
  const [drops, setDrops] = useState<Record<string, number>>({});
  const [prices, setPrices] = useState<Record<string, number>>({ "Tarantula Web": 110000 });
  const [hudOn, setHudOn] = useState(true);
  const [trackOn, setTrackOn] = useState(true);
  const [hudPos, setHudPos] = useState({ x: 12, y: 12 });
  const [gui, setGui] = useState<"none" | "tracker" | "editor">("none");
  const [held, setHeld] = useState("Water Bucket");
  const [chat, setChat] = useState<Line[]>([{ text: "Welcome to Hypixel SkyBlock!", color: "text-green-400" }]);
  const [input, setInput] = useState("");
  const [msgIdx, setMsgIdx] = useState(0);
  const chatRef = useRef<HTMLDivElement>(null);
  const screenRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{ ox: number; oy: number } | null>(null);

  useEffect(() => { chatRef.current?.scrollTo(0, 1e9); }, [chat]);

  const push = (text: string, color = "text-white") => setChat((c) => [...c.slice(-60), { text, color }]);
  const modMsg = (t: string) => push("[Tracker] " + t, "text-cyan-300");

  const record = (name: string, amt: number) => setDrops((d) => ({ ...d, [name]: (d[name] || 0) + amt }));

  // mirrors ChatListener.onChat - never blocks the message
  const receiveChat = (raw: string) => {
    push(raw, raw.includes("RARE DROP") ? "text-blue-300 font-semibold" : "text-gray-200");
    if (!trackOn) return;
    const t = raw.trim();
    let m = RARE_DROP.exec(t);
    if (m) return record(m[2].trim(), m[1] ? parseInt(m[1]) : 1);
    m = SACK_PICKUP.exec(t);
    if (m) return record(m[2].trim(), parseInt(m[1].replace(/,/g, "")));
    m = PICKUP.exec(t);
    if (m) return record(m[2].trim(), parseInt(m[1]));
  };

  const nextSlayerMsg = () => { receiveChat(SLAYER_MESSAGES[msgIdx % SLAYER_MESSAGES.length]); setMsgIdx((i) => i + 1); };

  const submit = () => {
    const v = input.trim();
    setInput("");
    if (!v) return;
    if (!v.startsWith("/")) return receiveChat("[MVP+] You: " + v);
    const [cmd, ...args] = v.slice(1).split(/\s+/);
    const c = cmd.toLowerCase();
    if (c === "setprice" || c === "sp") {
      if (!args.length) return modMsg("Usage: /setprice <price> [item name]");
      const p = parsePrice(args[0]);
      if (p === null) return modMsg("Invalid price: " + args[0]);
      const name = args.length > 1 ? args.slice(1).join(" ") : held;
      setPrices((pr) => ({ ...pr, [name]: p }));
      return modMsg(`Set price of ${name} to ${fmt(p)} coins`);
    }
    if (c === "trackergui" || c === "tracker" || c === "tg") return setGui("tracker");
    push("Unknown command. Type \"/help\" for help.", "text-red-400");
  };

  const total = Object.entries(drops).reduce((s, [k, v]) => s + (prices[k] || 0) * v, 0);

  // HUD dragging in editor
  const onMove = (e: React.MouseEvent) => {
    if (!drag.current || !screenRef.current) return;
    const r = screenRef.current.getBoundingClientRect();
    setHudPos({
      x: Math.max(0, Math.min(r.width - 180, e.clientX - r.left - drag.current.ox)),
      y: Math.max(0, Math.min(r.height - 60, e.clientY - r.top - drag.current.oy)),
    });
  };

  const Hud = (
    <div
      className={`absolute select-none rounded bg-black/60 px-2 py-1 font-mono text-[12px] leading-[15px] ${gui === "editor" ? "cursor-move ring-2 ring-cyan-400" : ""}`}
      style={{ left: hudPos.x, top: hudPos.y }}
      onMouseDown={(e) => {
        if (gui !== "editor") return;
        drag.current = { ox: e.nativeEvent.offsetX, oy: e.nativeEvent.offsetY };
      }}
    >
      <div className="font-bold text-cyan-300">Drop Tracker</div>
      {Object.keys(drops).length === 0 && <div className="text-gray-500">No drops yet</div>}
      {Object.entries(drops).slice(0, 8).map(([k, v]) => (
        <div key={k}>
          <span className="text-yellow-300">{k}</span><span className="text-gray-400">: </span>
          <span className="text-white">{v}</span>
          {prices[k] ? <span className="text-gray-500"> (<span className="text-amber-400">{fmt(prices[k] * v)}</span>)</span> : null}
        </div>
      ))}
      <div><span className="text-gray-400">Total: </span><span className="text-amber-400">{fmt(total)}</span></div>
    </div>
  );

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
      <div
        ref={screenRef}
        className="relative aspect-video overflow-hidden rounded-lg border border-neutral-700 bg-cover bg-center"
        style={{ backgroundImage: "url(/images/spiders-den.jpg)" }}
        onMouseMove={onMove}
        onMouseUp={() => (drag.current = null)}
        onMouseLeave={() => (drag.current = null)}
      >
        {/* HUD */}
        {hudOn && gui !== "tracker" && Hud}

        {/* Hotbar */}
        <div className="absolute bottom-2 left-1/2 flex -translate-x-1/2 gap-0.5 rounded bg-black/50 p-1">
          {HELD_ITEMS.map((it) => (
            <button key={it} title={it} onClick={() => setHeld(it)}
              className={`h-9 w-9 rounded border text-[9px] leading-tight ${held === it ? "border-white bg-white/20" : "border-neutral-600 bg-neutral-800/70"} text-gray-200`}>
              {it.split(" ").map((w) => w[0]).join("")}
            </button>
          ))}
        </div>
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 font-mono text-sm text-white drop-shadow">{held}</div>

        {/* Chat */}
        <div ref={chatRef} className="absolute bottom-16 left-1 max-h-[45%] w-[62%] overflow-y-auto font-mono text-[11px] leading-[14px]">
          {chat.map((l, i) => (
            <div key={i} className={`bg-black/40 px-1 ${l.color}`}>{l.text}</div>
          ))}
        </div>

        {/* Tracker GUI */}
        {gui === "tracker" && (
          <div className="absolute inset-0 flex flex-col items-center bg-black/60 p-3 font-mono text-[12px]">
            <div className="mb-2 font-bold text-cyan-300">Drop Tracker</div>
            <div className="grid w-80 grid-cols-2 gap-1">
              <McButton onClick={() => setHudOn(!hudOn)}>HUD: <span className={hudOn ? "text-green-400" : "text-red-400"}>{hudOn ? "ON" : "OFF"}</span></McButton>
              <McButton onClick={() => setTrackOn(!trackOn)}>Tracking: <span className={trackOn ? "text-green-400" : "text-red-400"}>{trackOn ? "ON" : "OFF"}</span></McButton>
              <McButton onClick={() => setGui("editor")}>Move HUD (drag)</McButton>
              <McButton onClick={() => setDrops({})}><span className="text-red-400">Reset drops</span></McButton>
            </div>
            <div className="mt-2 w-80 flex-1 overflow-auto rounded bg-black/60 p-1.5">
              <div className="grid grid-cols-[1fr_60px_70px] text-gray-400"><span>Item</span><span>Amount</span><span>Value</span></div>
              {Object.entries(drops).map(([k, v]) => (
                <div key={k} className="grid grid-cols-[1fr_60px_70px]">
                  <span className="truncate text-yellow-300">{k}</span>
                  <span>x{v}</span>
                  <span className={prices[k] ? "text-amber-400" : "text-gray-600"}>{prices[k] ? fmt(prices[k] * v) : "no price"}</span>
                </div>
              ))}
              {Object.keys(drops).length === 0 && <div className="mt-4 text-center text-gray-600">No drops tracked yet</div>}
            </div>
            <div className="mt-1 text-gray-400">Total: <span className="text-amber-400">{fmt(total)} coins</span></div>
            <McButton className="mt-2 w-28" onClick={() => setGui("none")}>Close</McButton>
          </div>
        )}
        {gui === "editor" && (
          <div className="pointer-events-none absolute inset-x-0 top-1 text-center font-mono text-[11px] text-gray-300">
            Drag the HUD to move it. Press ESC to save.
            <button className="pointer-events-auto ml-2 rounded bg-neutral-700 px-2 text-white" onClick={() => setGui("tracker")}>ESC</button>
          </div>
        )}

        {/* Input */}
        <form className="absolute inset-x-0 bottom-0 flex" onSubmit={(e) => { e.preventDefault(); submit(); }}>
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type /trackergui or /setprice 110k ..."
            className="w-full bg-black/70 px-2 py-1 font-mono text-xs text-white outline-none placeholder:text-gray-500" />
        </form>
      </div>

      <div className="space-y-3 text-sm">
        <div className="rounded-lg border border-neutral-800 bg-neutral-900 p-3">
          <div className="mb-2 font-semibold text-white">Simulate server chat</div>
          <button onClick={nextSlayerMsg} className="w-full rounded bg-cyan-600 px-3 py-2 font-medium text-white hover:bg-cyan-500">
            Receive next slayer message
          </button>
          <p className="mt-2 text-xs text-neutral-400">Next: <span className="font-mono text-neutral-300">{SLAYER_MESSAGES[msgIdx % SLAYER_MESSAGES.length]}</span></p>
        </div>
        <div className="rounded-lg border border-neutral-800 bg-neutral-900 p-3">
          <div className="mb-2 font-semibold text-white">Try these</div>
          <ul className="space-y-1 font-mono text-xs text-neutral-300">
            <li><Cmd set={setInput}>/trackergui</Cmd> open the tracker GUI</li>
            <li><Cmd set={setInput}>/setprice 110k</Cmd> price for held item</li>
            <li><Cmd set={setInput}>/setprice 2.5m Fly Swatter</Cmd> price by name</li>
            <li><Cmd set={setInput}>hello</Cmd> normal chat still works</li>
          </ul>
          <p className="mt-2 text-xs text-neutral-500">Click a hotbar slot to change the held item (e.g. Water Bucket).</p>
        </div>
        <div className="rounded-lg border border-neutral-800 bg-neutral-900 p-3 text-xs text-neutral-400">
          <div className="mb-1 font-semibold text-white">Prices</div>
          {Object.entries(prices).map(([k, v]) => <div key={k}><span className="text-yellow-300">{k}</span> → <span className="text-amber-400">{fmt(v)}</span></div>)}
        </div>
      </div>
    </div>
  );
}

function McButton({ children, onClick, className = "" }: { children: React.ReactNode; onClick: () => void; className?: string }) {
  return (
    <button onClick={onClick} className={`rounded-sm border border-black bg-neutral-500/80 px-2 py-1 text-white shadow-[inset_0_-2px_0_rgba(0,0,0,.4),inset_0_2px_0_rgba(255,255,255,.3)] hover:bg-blue-500/80 ${className}`}>
      {children}
    </button>
  );
}
function Cmd({ children, set }: { children: string; set: (s: string) => void }) {
  return <button onClick={() => set(children)} className="mr-1 rounded bg-neutral-800 px-1.5 py-0.5 text-cyan-300 hover:bg-neutral-700">{children}</button>;
}
